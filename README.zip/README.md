📝 Todo List & 🪨📄✂️ Rock-Paper-Scissors Game
A mini-project collection using HTML, CSS, and JavaScript.

📌 1. Todo List App
Features:

Add tasks with due dates

Delete tasks

Clean UI with CSS Grid layout

Tech: HTML, CSS (Grid), JavaScript

🎮 2. Rock-Paper-Scissors Game
Features:

Play against computer

Score tracking (with localStorage)

Auto Play mode (every second)

Reset and emoji-based move display
